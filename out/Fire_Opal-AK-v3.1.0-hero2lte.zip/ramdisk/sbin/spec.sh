#!/system/bin/sh

# Set first parameter to profile
profile=$1

# Function to apply ramdisk style settings
function write() {
    echo -n $2 > $1
}

# Load profile data
source /data/media/0/Spectrum/profiles/${profile}.profile;
