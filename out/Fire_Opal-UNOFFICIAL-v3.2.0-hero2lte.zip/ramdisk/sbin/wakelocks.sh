#!/system/bin/sh
#
# Copyright (C) 2017 Michele Beccalossi <beccalossi.michele@gmail.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#

mount -o remount,rw -t auto /
mount -t rootfs -o remount,rw rootfs
mount -o remount,rw -t auto /system
mount -o remount,rw /data
mount -o remount,rw /cache

# deepsleep fix
su -c 'echo "temporary none" >> /sys/class/scsi_disk/0:0:0:0/cache_type'
su -c 'echo "temporary none" >> /sys/class/scsi_disk/0:0:0:1/cache_type'
su -c 'echo "temporary none" >> /sys/class/scsi_disk/0:0:0:2/cache_type'
su -c 'echo "temporary none" >> /sys/class/scsi_disk/0:0:0:3/cache_type'

# Google Play services wakelock fix
sleep 1
su -c "pm enable com.google.android.gms/.update.SystemUpdateActivity"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService$ActiveReceiver"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService$Receiver"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService$SecretCodeReceiver"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateActivity"
su -c "pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService$Receiver"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService$SecretCodeReceiver"


# WakeUp Parameter
 	chmod 644 /sys/module/wakeup/parameters/enable_sensorhub_wl
 	echo "N" > /sys/module/wakeup/parameters/enable_sensorhub_wl
	chmod 644 /sys/module/wakeup/parameters/enable_ssp_wl
	echo "N" > /sys/module/wakeup/parameters/enable_ssp_wl
	chmod 644 /sys/module/wakeup/parameters/enable_bcmdhd4359_wl
	echo "N" > /sys/module/wakeup/parameters/enable_bcmdhd4359_wl
	chmod 644 /sys/module/wakeup/parameters/enable_wlan_wake_wl
	echo "N" > /sys/module/wakeup/parameters/enable_wlan_wake_wl
	chmod 644 /sys/module/wakeup/parameters/enable_bluedroid_timer_wl
	echo "N" > /sys/module/wakeup/parameters/enable_bluedroid_timer_wl
	chmod 644 /sys/module/wakeup/parameters/enable_mmc0_detect_wl
	echo "N" > /sys/module/wakeup/parameters/enable_mmc0_detect_wl
	chmod 644 /sys/module/wakeup/parameters/enable_wlan_ctrl_wake_wl
	echo "N" > /sys/module/wakeup/parameters/enable_wlan_ctrl_wake_wl
	chmod 644 /sys/module/wakeup/parameters/enable_wlan_rx_wake_wl
	echo "N" > /sys/module/wakeup/parameters/enable_wlan_rx_wake_wl
	chmod 644 /sys/module/wakeup/parameters/enable_wlan_wd_wake_wl
	echo "N" > /sys/module/wakeup/parameters/enable_wlan_wd_wake_wl

mount -o remount,ro -t auto /
mount -t rootfs -o remount,ro rootfs
mount -o remount,ro -t auto /system
mount -o remount,rw /data
mount -o remount,rw /cache
